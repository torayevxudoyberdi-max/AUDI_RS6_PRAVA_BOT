# 🚗 Koreya haydovchilik guvohnomasi — Telegram test boti

Manba: «1·2종 학과시험 문제은행 (2026.3.9 시행)» — 1000 ta savol (287 tasi rasmli).

## Ishga tushirish
1. Telegramda **@BotFather** → `/newbot` → token oling.
2. Python 3.10+ o'rnatilgan bo'lsin, so'ng:
   ```
   pip install -r requirements.txt
   export BOT_TOKEN="123456:ABC..."      # Windows: set BOT_TOKEN=123456:ABC...
   python bot.py
   ```
3. Botga `/start` yuboring.

Bot polling rejimida ishlaydi (webhook/domen shart emas). Doimiy ishlashi uchun
VPS'da `systemd`, `screen`/`tmux` yoki Docker ishlating.

## Rejimlar
- 📝 **Imtihon** — 40 ta tasodifiy savol, javob ko'rsatilmaydi, oxirida ball va xatolar (1-tur: 70, 2-tur: 60 ball).
- 🎯 **Tasodifiy mashq** — har javobdan keyin to'g'ri javob va izoh.
- 🖼 **Rasmli savollar** — faqat vaziyat/rasmli savollar.
- 📚 **Bo'limlar** — 50 tadan ketma-ket (1–50, 51–100 …).
- 🔢 **Raqam bo'yicha** — raqam yuboring (masalan `681`) — shu savoldan boshlanadi.
- 🌐 **O'zbekcha** tugmasi — savolni mashina tarjimasida ko'rsatadi (izoh javobdan keyin). Tarjima keshlanadi.
- ❌ **Xatolarim** — oxirgi marta xato qilingan savollar.
- 📊 **Statistika** — aniqlik va oxirgi imtihonlar.

"2가지" savollarda 2 ta javob belgilab «Tasdiqlash» bosiladi (ikkalasi ham to'g'ri bo'lsa hisoblanadi).

## Fayllar
- `bot.py` — Telegram qismi, `quiz.py` — mantiq va SQLite, `translate.py` — tarjima
- `questions.json` — savollar (`id, q, o, a, ctx, e, img`)
- `images/` — rasmlar (`q<raqam>_<n>.jpg`)
- Ishlaganda avtomatik yaratiladi: `data.db` (statistika), `state.pkl` (sessiyalar), `file_ids.json` (rasm keshi)

## Eslatma
Haqiqiy imtihonda savollar 2–5 ball turlicha baholanadi; botda har savol 2,5 ball deb olingan.
O'tish ballari `quiz.py` ichidagi `PASS_SCORE` da.

## Telefonda (Android, Termux)
1. Termux'ni **F-Droid**dan o'rnating (Play Market versiyasi eskirgan).
2. `pkg update -y && pkg install -y python unzip`
3. `termux-setup-storage` (ruxsat bering), zip'ni telefonga yuklab oling.
4. `cd ~ && unzip ~/storage/downloads/koreya_prava_bot.zip && cd bot`
5. `pip install -r requirements.txt`
6. `export BOT_TOKEN="..."` → `termux-wake-lock` → `python bot.py`

Bot faqat Termux ochiq va telefon internetda bo'lgandagina javob beradi.
