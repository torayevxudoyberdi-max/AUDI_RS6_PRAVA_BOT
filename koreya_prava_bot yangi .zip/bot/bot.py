# -*- coding: utf-8 -*-
"""Koreya haydovchilik guvohnomasi (1·2-tur) nazariy imtihoni — Telegram bot.

Ishga tushirish:
    export BOT_TOKEN="123456:ABC..."   # @BotFather dan olingan token
    python bot.py
"""
import json
import logging
import os
import random
import time
from pathlib import Path

from telegram import InlineKeyboardButton as Btn
from telegram import InlineKeyboardMarkup as Markup
from telegram import InputMediaPhoto, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    PersistenceInput,
    PicklePersistence,
    filters,
)

import quiz
import translate
from quiz import ALL_IDS, CIRCLED, IMG_DIR, QUESTIONS, TOTAL

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO
)
log = logging.getLogger("hayduvchi-bot")
HTML = ParseMode.HTML

# ------------------------------------------------------------ file_id keshi
CACHE_FILE = Path(__file__).resolve().parent / "file_ids.json"
try:
    FILE_IDS = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
except Exception:
    FILE_IDS = {}


def _save_cache() -> None:
    try:
        CACHE_FILE.write_text(json.dumps(FILE_IDS), encoding="utf-8")
    except OSError:
        log.warning("file_ids.json yozib bo'lmadi")


async def send_images(bot, chat_id: int, names: list) -> None:
    """Savolga tegishli rasm(lar)ni yuboradi. Birinchi marta fayldan, keyin file_id orqali."""
    for attempt in (0, 1):
        use_cache = attempt == 0
        srcs = [(FILE_IDS.get(n) if use_cache else None) or (IMG_DIR / n) for n in names]
        try:
            if len(srcs) == 1:
                msgs = [await bot.send_photo(chat_id, srcs[0])]
            else:
                msgs = await bot.send_media_group(chat_id, [InputMediaPhoto(s) for s in srcs])
            for n, m in zip(names, msgs):
                FILE_IDS[n] = m.photo[-1].file_id
            _save_cache()
            return
        except BadRequest:
            if attempt == 1:
                raise
            for n in names:           # file_id eskirgan bo'lishi mumkin
                FILE_IDS.pop(n, None)


# ------------------------------------------------------------ klaviaturalar
def menu_kb() -> Markup:
    return Markup([
        [Btn("📝 Imtihon · 1-tur (70 ball)", callback_data="ex:1")],
        [Btn("📝 Imtihon · 2-tur (60 ball)", callback_data="ex:2")],
        [Btn("🎯 Tasodifiy mashq", callback_data="pr"),
         Btn("🖼 Rasmli savollar", callback_data="img")],
        [Btn("📚 Bo'limlar (1–1000)", callback_data="blk"),
         Btn("🔢 Raqam bo'yicha", callback_data="num")],
        [Btn("❌ Xatolarim ustida ishlash", callback_data="wr")],
        [Btn("📊 Statistika", callback_data="st")],
    ])


def question_kb(s: dict, q: dict, reveal: bool = False) -> Markup:
    rows = []
    if not reveal:
        chosen = s["chosen"]
        rows.append([
            Btn(("✅ " if i in chosen else "") + CIRCLED[i - 1], callback_data=f"a:{q['id']}:{i}")
            for i in range(1, len(q["o"]) + 1)
        ])
        if len(q["a"]) > 1 and len(chosen) == len(q["a"]):
            rows.append([Btn("✔️ Tasdiqlash", callback_data=f"ok:{q['id']}")])
        rows.append([Btn("🌐 O'zbekcha", callback_data=f"tr:{q['id']}:0")])
        if s["mode"] == "exam":
            rows.append([Btn("🏁 Imtihonni tugatish", callback_data="fin")])
        else:
            rows.append([Btn("⏭ O'tkazib yuborish", callback_data="nx"),
                         Btn("🏠 Menyu", callback_data="menu")])
    else:
        rows.append([Btn("🌐 O'zbekcha", callback_data=f"tr:{q['id']}:1")])
        rows.append([Btn("➡️ Keyingi savol", callback_data="nx")])
        rows.append([Btn("🏠 Menyu", callback_data="menu")])
    return Markup(rows)


# ------------------------------------------------------------ yordamchilar
def sess(ctx):
    return ctx.user_data.get("s")


def header_for(s: dict) -> str:
    if s["mode"] in ("exam", "wrong", "img", "blk"):
        return f"[{s['i'] + 1}/{len(s['queue'])}] "
    return ""


async def safe_edit(query, text: str, markup=None) -> None:
    try:
        await query.edit_message_text(text, parse_mode=HTML, reply_markup=markup)
    except BadRequest as e:
        if "not modified" not in str(e).lower():
            raise


async def strip_kb(query) -> None:
    try:
        await query.edit_message_reply_markup(reply_markup=None)
    except TelegramError:
        pass


async def send_menu(bot, chat_id: int) -> None:
    text = (
        "🚗 <b>Koreya haydovchilik guvohnomasi — nazariy imtihon</b>\n"
        f"1·2-tur savollar banki (2026.3.9 dan amalda): <b>{TOTAL}</b> ta savol, "
        f"shundan <b>{len(quiz.IMAGE_IDS)}</b> tasi rasmli.\n\n"
        "Rejimni tanlang 👇"
    )
    await bot.send_message(chat_id, text, parse_mode=HTML, reply_markup=menu_kb())


# ------------------------------------------------------------ sessiya
async def start_session(ctx, chat_id: int, mode: str, queue: list, **extra) -> None:
    if not queue:
        await ctx.bot.send_message(chat_id, "Savollar topilmadi.")
        return
    ctx.user_data["s"] = dict(
        mode=mode, queue=list(queue), i=0, chosen=[], done=False,
        answers={}, t0=time.time(), **extra,
    )
    await show_current(ctx, chat_id)


async def show_current(ctx, chat_id: int) -> None:
    s = sess(ctx)
    q = QUESTIONS[s["queue"][s["i"]]]
    s["chosen"], s["done"] = [], False
    if q["img"]:
        await send_images(ctx.bot, chat_id, q["img"])
    await ctx.bot.send_message(
        chat_id,
        quiz.format_question(q, header=header_for(s)),
        parse_mode=HTML,
        reply_markup=question_kb(s, q),
    )


async def advance(ctx, chat_id: int) -> None:
    s = sess(ctx)
    s["i"] += 1
    if s["i"] >= len(s["queue"]):
        if s["mode"] == "exam":
            await finish_exam(ctx, chat_id, s["uid"])
        else:
            ctx.user_data["s"] = None
            await ctx.bot.send_message(chat_id, "✅ Savollar tugadi!")
            await send_menu(ctx.bot, chat_id)
        return
    await show_current(ctx, chat_id)


async def finish_exam(ctx, chat_id: int, uid: int) -> None:
    s = sess(ctx)
    queue, answers = s["queue"], s["answers"]
    wrong = [
        qid for qid in queue
        if str(qid) not in answers or not quiz.is_correct(QUESTIONS[qid], answers[str(qid)])
    ]
    correct = len(queue) - len(wrong)
    score = correct * 100 / len(queue)
    need = quiz.PASS_SCORE[s["cls"]]
    secs = int(time.time() - s["t0"])
    quiz.save_exam(uid, s["cls"], correct, len(queue), secs)

    ctx.user_data["review"] = wrong
    ctx.user_data["review_ans"] = answers
    ctx.user_data["s"] = None

    verdict = "✅ <b>O'TDINGIZ!</b>" if score >= need else "❌ <b>O'tolmadingiz</b>"
    text = (
        f"🏁 <b>Imtihon yakunlandi ({s['cls']}-tur)</b>\n\n"
        f"To'g'ri javoblar: <b>{correct} / {len(queue)}</b>\n"
        f"Ball: <b>{score:.1f}</b> / 100  (o'tish bali: {need})\n"
        f"{verdict}\n"
        f"⏱ Vaqt: {secs // 60} daq {secs % 60} son  (haqiqiy imtihonda 40 daqiqa)\n\n"
        "<i>Eslatma: haqiqiy imtihonda savollar 2–5 ball turlicha baholanadi; "
        "bu yerda har bir savol teng (2,5 ball) hisoblanadi.</i>"
    )
    rows = []
    if wrong:
        rows.append([Btn(f"❌ Xatolarni ko'rish ({len(wrong)})", callback_data="rv:0")])
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    await ctx.bot.send_message(chat_id, text, parse_mode=HTML, reply_markup=Markup(rows))


async def show_review(ctx, chat_id: int, k: int) -> None:
    wrong = ctx.user_data.get("review") or []
    if not wrong:
        await send_menu(ctx.bot, chat_id)
        return
    k = max(0, min(k, len(wrong) - 1))
    q = QUESTIONS[wrong[k]]
    chosen = (ctx.user_data.get("review_ans") or {}).get(str(q["id"]), [])
    if q["img"]:
        await send_images(ctx.bot, chat_id, q["img"])
    nav = []
    if k > 0:
        nav.append(Btn("⬅️", callback_data=f"rv:{k - 1}"))
    if k < len(wrong) - 1:
        nav.append(Btn("➡️", callback_data=f"rv:{k + 1}"))
    rows = ([nav] if nav else []) + [
        [Btn("🌐 O'zbekcha", callback_data=f"tr:{q['id']}:1")],
        [Btn("🏠 Menyu", callback_data="menu")],
    ]
    await ctx.bot.send_message(
        chat_id,
        quiz.format_question(q, chosen, reveal=True, result=False, header=f"Xato {k + 1}/{len(wrong)} · "),
        parse_mode=HTML,
        reply_markup=Markup(rows),
    )


async def send_stats(bot, chat_id: int, uid: int) -> None:
    st = quiz.user_stats(uid)
    total = st["ok"] + st["bad"]
    acc = f"{st['ok'] * 100 / total:.0f}%" if total else "—"
    lines = [
        "📊 <b>Statistika</b>\n",
        f"Yechilgan savollar: <b>{st['unique']}</b> / {TOTAL}",
        f"To'g'ri: {st['ok']}  ·  Noto'g'ri: {st['bad']}  ·  Aniqlik: {acc}",
        f"Hozir xato holatda: <b>{st['wrong_now']}</b>",
    ]
    if st["exams"]:
        lines.append("\n🏁 <b>Oxirgi imtihonlar:</b>")
        for cls, ok, tot, ts in st["exams"]:
            score = ok * 100 / tot
            mark = "✅" if score >= quiz.PASS_SCORE[cls] else "❌"
            lines.append(f"{time.strftime('%d.%m.%Y', time.localtime(ts))} · {cls}-tur · {ok}/{tot} {mark}")
    await bot.send_message(
        chat_id, "\n".join(lines), parse_mode=HTML,
        reply_markup=Markup([[Btn("🏠 Menyu", callback_data="menu")]]),
    )


# ------------------------------------------------------------ javob berish
async def finalize(ctx, query, s: dict, q: dict) -> None:
    chosen = sorted(s["chosen"])
    ok = quiz.is_correct(q, chosen)
    s["answers"][str(q["id"])] = chosen
    s["done"] = True
    quiz.record_answer(query.from_user.id, q["id"], ok)
    chat_id = query.message.chat_id
    if s["mode"] == "exam":
        await safe_edit(query, f"<b>№ {q['id']}</b> — javobingiz: {quiz.letters(chosen)}")
        await advance(ctx, chat_id)
    else:
        await safe_edit(
            query,
            quiz.format_question(q, chosen, reveal=True, result=ok, header=header_for(s)),
            question_kb(s, q, reveal=True),
        )


async def handle_option(ctx, query, qid: int, i: int):
    s = sess(ctx)
    if not s or s["done"] or s["queue"][s["i"]] != qid:
        return "Bu savol allaqachon yopilgan."
    q = QUESTIONS[qid]
    need = len(q["a"])
    if need == 1:
        s["chosen"] = [i]
        await finalize(ctx, query, s, q)
        return None
    chosen = s["chosen"]
    if i in chosen:
        chosen.remove(i)
    elif len(chosen) < need:
        chosen.append(i)
    else:
        return f"Faqat {need} ta javob tanlanadi — avval birini bekor qiling."
    await safe_edit(
        query,
        quiz.format_question(q, chosen, header=header_for(s)),
        question_kb(s, q),
    )
    return None


# ------------------------------------------------------------ callback router
async def route(ctx, query, data: str):
    chat_id = query.message.chat_id
    uid = query.from_user.id

    if data == "menu":
        ctx.user_data["s"] = None
        await strip_kb(query)
        await send_menu(ctx.bot, chat_id)

    elif data.startswith("ex:"):
        await start_session(ctx, chat_id, "exam", quiz.make_exam(), cls=int(data[3:]), uid=uid)

    elif data == "pr":
        ids = ALL_IDS[:]
        random.shuffle(ids)
        await start_session(ctx, chat_id, "random", ids)

    elif data == "img":
        ids = quiz.IMAGE_IDS[:]
        random.shuffle(ids)
        await start_session(ctx, chat_id, "img", ids)

    elif data == "wr":
        ids = quiz.wrong_ids(uid)
        if not ids:
            return "Hozircha xatolaringiz yo'q 👍 Avval mashq qiling."
        random.shuffle(ids)
        await start_session(ctx, chat_id, "wrong", ids)

    elif data == "blk":
        rows, row = [], []
        for st in range(1, TOTAL + 1, quiz.BLOCK):
            row.append(Btn(f"{st}–{min(st + quiz.BLOCK - 1, TOTAL)}", callback_data=f"b:{st}"))
            if len(row) == 3:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
        rows.append([Btn("🏠 Menyu", callback_data="menu")])
        await ctx.bot.send_message(chat_id, "📚 Bo'limni tanlang:", reply_markup=Markup(rows))

    elif data.startswith("b:"):
        st = int(data[2:])
        await start_session(ctx, chat_id, "blk", list(range(st, min(st + quiz.BLOCK, TOTAL + 1))))

    elif data == "num":
        await ctx.bot.send_message(chat_id, f"Savol raqamini yuboring (1–{TOTAL}):")

    elif data == "st":
        await send_stats(ctx.bot, chat_id, uid)

    elif data.startswith("a:"):
        _, qid, i = data.split(":")
        return await handle_option(ctx, query, int(qid), int(i))

    elif data.startswith("ok:"):
        s = sess(ctx)
        qid = int(data[3:])
        if not s or s["done"] or s["queue"][s["i"]] != qid:
            return "Bu savol allaqachon yopilgan."
        q = QUESTIONS[qid]
        if len(s["chosen"]) != len(q["a"]):
            return f"Avval {len(q['a'])} ta javob tanlang."
        await finalize(ctx, query, s, q)

    elif data == "nx":
        s = sess(ctx)
        if not s:
            await send_menu(ctx.bot, chat_id)
        else:
            await strip_kb(query)
            await advance(ctx, chat_id)

    elif data == "fin":
        s = sess(ctx)
        if s and s["mode"] == "exam":
            await strip_kb(query)
            await finish_exam(ctx, chat_id, uid)
        else:
            return "Faol imtihon yo'q."

    elif data.startswith("tr:"):
        _, qid, r = data.split(":")
        q = QUESTIONS[int(qid)]
        try:
            await query.answer("Tarjima qilinmoqda…")
        except TelegramError:
            pass
        tr = await translate.get_translation(q)
        if not tr:
            return "Tarjima hozir ishlamadi. Birozdan so'ng qayta urinib ko'ring."
        await ctx.bot.send_message(
            chat_id, quiz.format_translation(q, tr, reveal=(r == "1")), parse_mode=HTML
        )

    elif data.startswith("rv:"):
        await strip_kb(query)
        await show_review(ctx, chat_id, int(data[3:]))
    return None


async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    note = None
    try:
        note = await route(ctx, query, query.data or "")
    except Exception:
        log.exception("callback xatosi: %s", query.data)
        note = "Xatolik yuz berdi. /start ni bosing."
    try:
        await query.answer(note) if note else await query.answer()
    except TelegramError:
        pass


# ------------------------------------------------------------ buyruqlar / matn
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    ctx.user_data["s"] = None
    await send_menu(ctx.bot, update.effective_chat.id)


async def cmd_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    await send_stats(ctx.bot, update.effective_chat.id, update.effective_user.id)


async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    text = (update.message.text or "").strip()
    chat_id = update.effective_chat.id
    if text.isdigit():
        n = int(text)
        if 1 <= n <= TOTAL:
            await start_session(ctx, chat_id, "seq", list(range(n, TOTAL + 1)))
        else:
            await update.message.reply_text(f"1 dan {TOTAL} gacha raqam yuboring.")
        return
    await send_menu(ctx.bot, chat_id)


async def on_error(update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Kutilmagan xato", exc_info=ctx.error)


async def post_init(app: Application) -> None:
    await app.bot.set_my_commands([
        ("start", "Bosh menyu"),
        ("menu", "Bosh menyu"),
        ("stats", "Statistika"),
    ])


def main() -> None:
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise SystemExit("BOT_TOKEN o'rnatilmagan. Masalan: export BOT_TOKEN='123456:ABC...'")
    quiz.init_db()
    persistence = PicklePersistence(
        filepath=str(Path(__file__).resolve().parent / "state.pkl"),
        store_data=PersistenceInput(bot_data=False, chat_data=False, callback_data=False),
    )
    app = Application.builder().token(token).persistence(persistence).post_init(post_init).build()
    app.add_handler(CommandHandler(["start", "menu"], cmd_start))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    app.add_error_handler(on_error)
    log.info("Bot ishga tushdi (%d ta savol, %d ta rasmli)", TOTAL, len(quiz.IMAGE_IDS))
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
