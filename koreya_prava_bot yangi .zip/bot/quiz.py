# -*- coding: utf-8 -*-
"""Savollar bazasi, matn formatlash va SQLite statistikasi (Telegramga bog'liq emas)."""
import html
import json
import random
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

BASE = Path(__file__).resolve().parent
IMG_DIR = BASE / "images"
DB_PATH = BASE / "data.db"

with open(BASE / "questions.json", encoding="utf-8") as f:
    QUESTIONS = {q["id"]: q for q in json.load(f)}

ALL_IDS = sorted(QUESTIONS)
TOTAL = len(ALL_IDS)
IMAGE_IDS = [i for i in ALL_IDS if QUESTIONS[i]["img"]]

CIRCLED = "①②③④⑤"
EXAM_SIZE = 40                 # haqiqiy imtihonda 40 ta savol
PASS_SCORE = {1: 70, 2: 60}    # 1-tur (제1종) 70 ball, 2-tur (제2종) 60 ball
POINTS_PER_Q = 100 / EXAM_SIZE
BLOCK = 50
MAX_LEN = 4000                 # Telegram limiti 4096


def esc(s: str) -> str:
    return html.escape(s, quote=False)


def is_correct(q: dict, chosen) -> bool:
    return sorted(chosen) == sorted(q["a"])


def make_exam() -> list:
    return random.sample(ALL_IDS, EXAM_SIZE)


def letters(nums) -> str:
    return " ".join(CIRCLED[i - 1] for i in sorted(nums)) or "—"


def format_question(q: dict, chosen=(), reveal=False, result=None, header="") -> str:
    need = len(q["a"])
    parts = [f"<b>{esc(header)}№ {q['id']}</b>", "", esc(q["q"])]
    if q["ctx"]:
        parts += ["", "\n".join("📍 " + esc(c) for c in q["ctx"])]
    parts.append("")
    for i, opt in enumerate(q["o"], start=1):
        if reveal:
            mark = "✅" if i in q["a"] else ("❌" if i in chosen else "▫️")
        else:
            mark = "🔹" if i in chosen else "▫️"
        parts.append(f"{mark} {CIRCLED[i - 1]} {esc(opt)}")
    parts.append("")
    if not reveal:
        if need == 1:
            parts.append("☝️ Bitta to'g'ri javobni tanlang.")
        else:
            parts.append(f"☝️ {need} ta to'g'ri javobni tanlang, so'ng «Tasdiqlash»ni bosing.")
        return "\n".join(parts)

    right = letters(q["a"])
    if result is True:
        parts.append(f"✅ <b>To'g'ri!</b> Javob: {right}")
    elif result is False:
        parts.append(f"❌ <b>Noto'g'ri.</b> To'g'ri javob: {right}")
    else:
        parts.append(f"To'g'ri javob: {right}")
    text = "\n".join(parts)
    if q["e"]:
        room = MAX_LEN - len(text) - 40
        if room > 50:
            expl = q["e"][:room] + ("…" if len(q["e"]) > room else "")
            text += "\n\n💡 <b>Izoh (한국어):</b> " + esc(expl)
    return text


# ---------------------------------------------------------------- SQLite
@contextmanager
def _db():
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with _db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS answers(
                user_id INTEGER, qid INTEGER,
                n_ok INTEGER DEFAULT 0, n_bad INTEGER DEFAULT 0,
                last_ok INTEGER, ts REAL,
                PRIMARY KEY(user_id, qid));
            CREATE TABLE IF NOT EXISTS exams(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER, cls INTEGER, correct INTEGER,
                total INTEGER, seconds INTEGER, ts REAL);
            CREATE TABLE IF NOT EXISTS tr(qid INTEGER PRIMARY KEY, data TEXT);
            """
        )


def record_answer(uid: int, qid: int, ok: bool) -> None:
    with _db() as c:
        c.execute(
            """INSERT INTO answers(user_id, qid, n_ok, n_bad, last_ok, ts)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(user_id, qid) DO UPDATE SET
                 n_ok = n_ok + excluded.n_ok, n_bad = n_bad + excluded.n_bad,
                 last_ok = excluded.last_ok, ts = excluded.ts""",
            (uid, qid, int(ok), int(not ok), int(ok), time.time()),
        )


def wrong_ids(uid: int) -> list:
    with _db() as c:
        rows = c.execute(
            "SELECT qid FROM answers WHERE user_id=? AND last_ok=0", (uid,)
        ).fetchall()
    return [r[0] for r in rows]


def save_exam(uid: int, cls: int, correct: int, total: int, seconds: int) -> None:
    with _db() as c:
        c.execute(
            "INSERT INTO exams(user_id, cls, correct, total, seconds, ts) VALUES(?,?,?,?,?,?)",
            (uid, cls, correct, total, seconds, time.time()),
        )


def user_stats(uid: int) -> dict:
    with _db() as c:
        a = c.execute(
            "SELECT COUNT(*), COALESCE(SUM(n_ok),0), COALESCE(SUM(n_bad),0), "
            "COALESCE(SUM(CASE WHEN last_ok=0 THEN 1 ELSE 0 END),0) "
            "FROM answers WHERE user_id=?", (uid,),
        ).fetchone()
        ex = c.execute(
            "SELECT cls, correct, total, ts FROM exams WHERE user_id=? ORDER BY id DESC LIMIT 5",
            (uid,),
        ).fetchall()
    return dict(unique=a[0], ok=a[1], bad=a[2], wrong_now=a[3], exams=ex)


# ---------------------------------------------------------------- tarjima keshi
def get_tr(qid: int):
    with _db() as c:
        row = c.execute("SELECT data FROM tr WHERE qid=?", (qid,)).fetchone()
    return json.loads(row[0]) if row else None


def set_tr(qid: int, data: dict) -> None:
    with _db() as c:
        c.execute("INSERT OR REPLACE INTO tr(qid, data) VALUES(?,?)",
                  (qid, json.dumps(data, ensure_ascii=False)))


def format_translation(q: dict, tr: dict, reveal: bool = False) -> str:
    parts = [f"🌐 <b>№ {q['id']} — o'zbekcha tarjima</b>",
             "<i>(mashina tarjimasi, taxminiy)</i>", "", esc(tr["q"])]
    if tr.get("ctx"):
        parts += ["", "\n".join("📍 " + esc(c) for c in tr["ctx"])]
    parts.append("")
    for i, o in enumerate(tr["o"], start=1):
        parts.append(f"{CIRCLED[i - 1]} {esc(o)}")
    text = "\n".join(parts)
    if reveal and tr.get("e"):
        room = MAX_LEN - len(text) - 40
        if room > 50:
            text += "\n\n💡 <b>Izoh:</b> " + esc(tr["e"][:room])
    return text
