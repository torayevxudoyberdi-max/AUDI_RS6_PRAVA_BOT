# -*- coding: utf-8 -*-
"""Koreyscha → o'zbekcha mashina tarjimasi (Google Translate'ning ochiq endpointi, kalitsiz).
Natija SQLite'da keshlanadi, shuning uchun har savol faqat bir marta tarjima qilinadi."""
import asyncio
import json
import logging
import urllib.parse
import urllib.request

import quiz

log = logging.getLogger("translate")
_URL = "https://translate.googleapis.com/translate_a/single?" + urllib.parse.urlencode(
    {"client": "gtx", "sl": "ko", "tl": "uz", "dt": "t"}
)


def _call(text: str) -> str:
    body = urllib.parse.urlencode({"q": text}).encode("utf-8")
    req = urllib.request.Request(
        _URL, data=body,
        headers={"User-Agent": "Mozilla/5.0",
                 "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"},
    )
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read().decode("utf-8"))
    return "".join(seg[0] for seg in data[0] if seg and seg[0])


def _translate_pieces(pieces: list) -> list:
    out = _call("\n".join(pieces)).split("\n")
    if len(out) == len(pieces):
        return [o.strip() for o in out]
    return [_call(p).strip() for p in pieces]      # qator soni mos kelmasa — bittadan


def _build(q: dict) -> dict:
    pieces = [q["q"]] + list(q["ctx"]) + list(q["o"]) + ([q["e"]] if q["e"] else [])
    out = _translate_pieces(pieces)
    nc, no = len(q["ctx"]), len(q["o"])
    return {
        "q": out[0],
        "ctx": out[1:1 + nc],
        "o": out[1 + nc:1 + nc + no],
        "e": out[1 + nc + no] if q["e"] else "",
    }


async def get_translation(q: dict):
    cached = quiz.get_tr(q["id"])
    if cached:
        return cached
    try:
        tr = await asyncio.to_thread(_build, q)
    except Exception:
        log.exception("tarjima xatosi (savol %s)", q["id"])
        return None
    quiz.set_tr(q["id"], tr)
    return tr
